##########################################################################################
# 23/24.4.2019
# PYTHON - 2gi TERMIN
# NIZI
################################################################################


# Kako poženemo .py datoteko iz Notepad++
#	označi in kopiraj v odložišče (ctrl+c) 
#	Odpri Run -> Run 
#	desni klik na python3.6 properties skopiramo targer, dodaj "$(FULL_CURRRENT_PATH)"
#	shrani in dodaj nekakšno kombinacijo tipk (alt + r)
#	http://docs.notepad-plus-plus.org/index.php?title=External_Programs



# Naslednja koda vsebuje, kar se zamikov tiče, cel kup napak.
# 
#         x = int(input('x: '))
#         y = int(input('y: '))
#         if x == 3 and y == 4:
#             print("x je 3")
#                print("y je morda 4, vem pa ne")
#         if x > 2 and y < 5:
#         print("x > 2")
#         print("y < 5")
#         if x < 4 and y > 3:
#             print("x < 4")
#                 print("y > 3")
# 
# Skopiraj jo in jo popravi! Stavkov samih ne spreminjaj, le njihove zamike!
# Popravki morajo biti taki, da so izpisi smiselni!

# IN


# 1. V povedi: "VčeRaj jE bIL SonČEn dAn". 
#	a) Poišči in izpiši črko na 5tem mestu

#	b) Izpiši dolžino niza (stringa)

#	c) Izpiši niz med 3jim in 9im mestom.

# 	c) Vse prve črke besede spremeni v velike, vse ostale v majhne

#	d) Če poved vsebuje besedo sončen izpiši "Res je bil."

#	e) Zamenjaj vse e-je v u-je

# IN


# 2. 
#	a) Sestavi seznam z tremi števili.

#	b) Izpiši ta seznam

#	c) dodaj števili 11 in 24 na konec seznama

#	d) ponovno izpiši ta seznam

#	e) poišči najmanjšo in njavečjo številko v seznamu

# 	f) izpiši seznam v nasportnem vrstnem redu

