# 1. Preštej koliko krat se pojavijo samoglasniki v besedah : Dialéktičnomaterialístičen, buržoaznonacionalističen, starocerkvenoslovanščina



# 2.
# Sestavite funkcijo `vsota_kvadratov_stevk(n)`, ki vrne vsoto kvadratov števk
# *tromestnega* števila `n`.
# 
#     >>> vsota_kvadratov_stevk(123)
#     14



# 3.
#	a) Sestavite funkcijo `obrat(n)`, ki vrne število, ki ga dobimo, če številu `n`
# zamenjamo števki na mestu enic in stotic.
 
#     >>> obrat(123)
#     321


#	b) Sestavi funkcijo še za poljubno dolgo število ali besedo.



# 4. Imaš paleto 6ih barv (modra, rdeča, zelena, rumena, bela, črna) imaš 5 znamk avtomobilov (Ferrari, Renault, BMW, Mazda, Seat)

# Ferrariji so lahko le rdeči in rumeni
# Renaulti so lahko vseh barv razen modri
# BMWji so lahko beli, črni ali modri
# Mazde in Seati so lahko vseh barv

# Naj si oseba vnese kombinacijo barve in avta, če je le ta dovoljena izpiši "Dodaj v košarico", če ni odpiši da takšna kombinacija ni mogoča.



